package com.test.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AmazonPage extends BasePage {
	
	@FindBy(xpath="//input[@id='twotabsearchtextbox' and @placeholder='Search Amazon.in']")
	private WebElement searchinput;
	
	@FindBy(xpath="//input[@type='submit' and @value='Go']")
	WebElement searchIcon;

	public AmazonPage(WebDriver driver) {
		super(driver);
	}

	public void sendKeysToSearchBox(String key) {
		searchinput.sendKeys(key);
	}
	public void clickSearchBtn() {
		searchIcon.click();
	}

}
