package com.test.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;

import com.test.context.WebDriverContext;
import com.test.listeners.ReportListener;

import io.github.bonigarcia.wdm.WebDriverManager;

@Listeners({ ReportListener.class })
public class BaseTest {

	protected WebDriver driver;

	@BeforeClass
	protected void setup() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions cops = new ChromeOptions();
		cops.addArguments("disable-infobars");
		driver = new ChromeDriver(cops);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebDriverContext.setDriver(driver);
	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.close();
			driver.quit();
		}
	}
}
