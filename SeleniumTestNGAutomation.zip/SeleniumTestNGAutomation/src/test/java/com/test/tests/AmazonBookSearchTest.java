package com.test.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.test.factory.PageinstancesFactory;
import com.test.pages.AmazonPage;


@Test(testName = "Amazon.in Java Book search test", description = "Test Java Book search")
public class AmazonBookSearchTest extends BaseTest {

	@Test
	public void amazonJavaBookSearchTest() {
		driver.get("https://www.amazon.in/");
		AmazonPage amazonPage = PageinstancesFactory.getInstance(AmazonPage.class);
		amazonPage.sendKeysToSearchBox("Java");
		amazonPage.clickSearchBtn();
		Assert.assertTrue(driver.getTitle().contains("Java"), "Title doesn't contain Java : Test Failed");
	}
}

