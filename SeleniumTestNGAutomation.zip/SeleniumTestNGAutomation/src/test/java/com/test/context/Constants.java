package com.test.context;

public class Constants {

	public static final String WORKING_DIRECTORY = System.getProperty("user.dir");

	public final static String REPORT_DIRECTORY = WORKING_DIRECTORY + "/ExtentReports/Report.html";

	public final static String PROJECT_NAME = "test";

	public final static String EXTENT_CONFIG_PATH = WORKING_DIRECTORY + "/src/test/resources/config/extent-config.xml";

}
